DROP TABLE IF EXISTS `#__conference_days`;
DROP TABLE IF EXISTS `#__conference_events`;
DROP TABLE IF EXISTS `#__conference_levels`;
DROP TABLE IF EXISTS `#__conference_rooms`;
DROP TABLE IF EXISTS `#__conference_sessions`;
DROP TABLE IF EXISTS `#__conference_slots`;
DROP TABLE IF EXISTS `#__conference_speakers`;