<?php

/**
 * @version 1.0.0
 * @package perfectdashboard
 * @copyright © 2017 Perfect Dashboard Sp. z o.o., All rights reserved. https://perfectdashboard.com
 * @author Piotr Moćko
 */
defined('_JEXEC') or die();

class plgSystemPerfectDashboard_Installer extends JPlugin
{
    
}
